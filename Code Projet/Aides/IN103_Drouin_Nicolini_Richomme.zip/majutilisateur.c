/*Auteurs : Drouin ; Nicolini ; Richomme */

#include <stdlib.h>
#include <stdio.h>

#include "function.h"

/* PLACER ET EFFACER UNE PIECE DANS LA GRILLE */

// A chaque manipulation de l'utilisateur, on efface la pièce de la grille et on y place la suivante selon les instructions du joueur. On évite ainsi d'écraser la pièce dans la grille.

void effacer(int* grille, struct piece une_piece , int largeur)
	{
		int abs = une_piece.abs_centre ;
		int ord = une_piece.ord_centre ;
		grille[abs + ord*largeur] = 0 ;
		grille[abs + une_piece.abs_1 + (ord + une_piece.ord_1)*largeur] = 0 ;
		grille[abs + une_piece.abs_2 + (ord + une_piece.ord_2)*largeur] = 0 ;
		grille[abs + une_piece.abs_3 + (ord + une_piece.ord_3)*largeur] = 0 ;
	}


void placer(int* grille, struct piece une_piece , int largeur)
// On ne vérifie pas ici si la pièce peut effectivement être placée dans la grille.
	{
		int abs = une_piece.abs_centre ;
		int ord = une_piece.ord_centre ;
		grille[abs + ord*largeur] = une_piece.couleur ;
		grille[abs + une_piece.abs_1 + (ord + une_piece.ord_1)*largeur] = une_piece.couleur ;
		grille[abs + une_piece.abs_2 + (ord + une_piece.ord_2)*largeur] = une_piece.couleur ;
		grille[abs + une_piece.abs_3 + (ord + une_piece.ord_3)*largeur] = une_piece.couleur ;
	}




// Deux mouvements sont possibles pour le joueur : le décalage et la rotation de la pièce. 


/* PREMIER MOUVEMENT : DECALAGE DE LA PIECE */

// La fonction suivante permet de vérifier si le décalage de la pièce dans la direction (droite ou gauche) voulue par le joueur est permis. 

int verif_decalage(int* grille, struct piece* une_piece, int largeur, int decalage) 
// 0 si on ne peut pas décaler (sortie de la grille ou présence d'un empilement à l'endroit on l'on veut décaler la pièce)
// 1 si on peut décaler

	{
		int verif = 0 ;

		int abs0 = une_piece->abs_centre ;
		int ord0 = une_piece->ord_centre ;
		int abs1 = une_piece->abs_1 ;
		int ord1 = une_piece->ord_1 ;
		int abs2 = une_piece->abs_2 ;
  		int ord2 = une_piece->ord_2 ;
		int abs3 = une_piece->abs_3 ;
		int ord3 = une_piece->ord_3 ;

		// On observe que pour chaque pièce, quelque soit sa rotation, il suffit de s'intéresser aux 3 cases autres que la case centrale pour voir si la pièce sort de la grille. 
		// La pièce sort-elle de la grille ?

		if (decalage == 1) //décalage vers la droite
			{
				if ( (abs0+abs1+1 >= largeur) || (abs0+abs2+1 >= largeur) || (abs0+abs3+1 >= largeur) ) return(verif) ;

			}

		if (decalage == -1) //décalage vers la gauche
			{
				if ( (abs0+abs1-1 < 0) || (abs0+abs2-1 < 0) || (abs0+abs3-1 < 0) ) return(verif) ;

			}

		// A ce point, la pièce ne sort pas de la grille. Mais y-a-t-il un empilement déjà présent dans la grille ? 

		if ( grille[abs0 + decalage + ord0*largeur] + grille[abs0+abs1 + decalage + (ord0+ord1)*largeur] + grille[abs0+abs2 + decalage + (ord0+ord2)*largeur] +  grille[abs0+abs3 + decalage + (ord0+ord3)*largeur] > 0 ) return(verif) ;

		// On peut désormais décaler la pièce vers la gauche ou vers la droite sans problèmes.
		verif = 1 ;
		return(verif) ;

	}

/* DEUXIEME MOUVEMENT : ROTATION DE LA PIECE */

// Les fonctions suivantes permettent de calculer, si la rotation est possible, les coordonnées des briques de la pièce après la rotation dans le sens voulu par le joueur, dans le repère de la brique centrale. 


int* calcul_rotation(int abscisse, int ordonnee, int rotation)
// Calcule l'abscisse et l'ordonnée d'une des briques de la pièce après la rotation.
// Ne vérifie pas si la rotation de cette brique de la pièce est permise.
	{
		int* coord_apres = malloc(2*sizeof(int)) ;
		if (coord_apres == NULL) return(NULL) ;		

		// rotation = 1 sens trigonométrique
		// rotation = -1 sens horaire
	
		coord_apres[0] = -ordonnee*rotation ; //abscisse après rotation
		coord_apres[1] = abscisse*rotation ; //ordonnée après rotation

		return(coord_apres) ;

	}	


int* coord_rotation(int* grille, struct piece* une_piece, int largeur, int hauteur, int rotation) 
// renvoie le tableau des coordonnées des briques de la pièce retournée dans le sens voulu si la rotation est possible.
// renvoie le pointeur sur tableau nul sinon.
	{	

		// Le bloc carré ne fait pas de rotation. 
		if(une_piece->couleur == 1) return(NULL) ;

		int abs0 = une_piece->abs_centre;
		int ord0 = une_piece->ord_centre;
		int abs1 = une_piece->abs_1 ;
		int ord1 = une_piece->ord_1 ;
		int abs2 = une_piece->abs_2 ;
		int ord2 = une_piece->ord_2 ;
		int abs3 = une_piece->abs_3 ;
		int ord3 = une_piece->ord_3 ;

		int* coord = malloc(6*sizeof(int)) ;
		if (coord == NULL) return(NULL);
		coord[0] = abs1 ;
		coord[1] = ord1 ;
		coord[2] = abs2 ;
		coord[3] = ord2 ;
		coord[4] = abs3 ;
		coord[5] = ord3 ;
		
		// Calcul des coordonnées de chaque brique de la pièce, une fois retournée.
		// La brique centrale ne fait pas de rotation. 
		for( int i = 0 ; i<3 ; i++ )
			{
				int* coord_case = calcul_rotation(coord[2*i], coord[2*i+1], rotation) ;
				if (coord_case == NULL) 
					{ free(coord) ; return(NULL) ; }
				coord[2*i] = coord_case[0] ;
				coord[2*i+1] = coord_case[1] ;
				free(coord_case) ;
			}


		// On vérifie si la rotation de la pièce est possible : la pièce sort-elle de la grille et y-a-t-il un empilement présent empêchant la rotation ?
		
		abs1 = coord[0] ;
		ord1 = coord[1] ;
		abs2 = coord[2] ;
		ord2 = coord[3] ;
		abs3 = coord[4] ;
		ord3 = coord[5] ;
		
		// On observe que pour chaque pièce, quelque soit son orientation, il suffit de s'intéresser aux 3 cases autres que la case centrale pour savoir si la pièce sort de la grille.
		// Si la pièce retournée sort de la grille, on renvoie le pointeur nul. 
		if ( ((abs1+abs0)>=largeur)||((abs2+abs0)>=largeur)||((abs3+abs0)>=largeur)||((abs1+abs0)<0)||((abs2+abs0)<0)||((abs3+abs0)<0)||((ord1+ord0)<0)||((ord2+ord0)<0)||((ord3+ord0)<0)||((ord1+ord0)>=hauteur)||((ord2+ord0)>=hauteur)||((ord3+ord0)>=hauteur) )
			{ free(coord) ; return(NULL) ; }

		// On vérifie la présence d'un empilement gênant la rotation de la pièce.
		// La case centrale ne bouge pas lors d'une rotation, on ne vérifie que les 3 cases restantes.
		// S'il s'avère que la rotation n'est pas possible, on renvoie le pointeur nul. 

		if ( grille[abs0+abs1 + (ord0+ord1)*largeur] + grille[abs0+abs2 + (ord0+ord2)*largeur] + grille[abs0+abs3 + (ord0+ord3)*largeur] > 0 ) 
			{ free(coord) ; return(NULL) ; }

		// A ce point, la rotation est possible.
		return(coord) ;

	} 



/* MISE A JOUR DE LA GRILLE */

void traitement_utilisateur(int* grille, struct piece* une_piece, int largeur, int hauteur, int rotation, int decalage) 
	{
		if(decalage !=0) // si le joueur veut décaler la pièce
			{
				effacer(grille, *une_piece, largeur) ;
				int verif = verif_decalage(grille, une_piece, largeur, decalage) ;
				if (verif == 1)
					{
						une_piece->abs_centre += decalage ;
					}
				placer(grille, *une_piece , largeur) ;
			}


		if(rotation !=0) // si le joueur veut faire tourner la pièce
			{
				effacer(grille, *une_piece, largeur) ;
				int* tourner = coord_rotation (grille, une_piece, largeur, hauteur, rotation) ;
				if (tourner != NULL) 
					{
						une_piece->abs_1 = tourner[0] ;
						une_piece->ord_1 = tourner[1] ;
						une_piece->abs_2 = tourner[2] ;
						une_piece->ord_2 = tourner[3] ;
						une_piece->abs_3 = tourner[4] ;
						une_piece->ord_3 = tourner[5] ;
					}
				
				placer(grille, *une_piece, largeur) ;
				free(tourner) ;
			}

	} 








