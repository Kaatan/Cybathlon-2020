/*Auteurs : Drouin ; Nicolini ; Richomme */

#include <stdlib.h>
#include <stdio.h>
#include <stdbool.h>

#include "function.h" 

#define SCORE_POSE 5
#define SCORE_1LIGNE 50
#define SCORE_2LIGNE 150
#define SCORE_3LIGNE 450
#define SCORE_4LIGNE 1350

bool perdu(int* grille, int largeur) 
// false si on a n'a pas perdu
// true si on a perdu
	{
		int win = 0 ;
		for(int j = 0 ; j<3 ; j++)
			{
				for(int i = 0 ; i<largeur ; i++) 
					{
						win += grille[i + j*largeur] ;
						// si il y a une brique d'une pièce dans les lignes fantômes, celle-ci n'a pas pu descendre, on a perdu.
						if(win>0) return(true) ;

					}
			}
		return(false) ;

	}


bool contact (int* grille, struct piece* piece, int largeur, int hauteur) {

	int abs0 = piece->abs_centre ;
	int ord0 = piece->ord_centre ;
	int abs1 = piece->abs_1 ;
	int ord1 = piece->ord_1 ;
	int abs2 = piece->abs_2 ;
  	int ord2 = piece->ord_2 ;
	int abs3 = piece->abs_3 ;
	int ord3 = piece->ord_3 ;

	if (((ord0+1) >= hauteur) || ((ord0+ord1+1) >= hauteur) || ((ord0+ord2+1) >= hauteur) || ((ord0+ord3+1) >= hauteur)) return true;

	if (grille[abs0 + (ord0+1)*largeur] + grille[abs0+abs1 + (ord0+ord1+1)*largeur] + grille[abs0+abs2 + (ord0+ord2+1)*largeur] +  grille[abs0+abs3 + (ord0+ord3+1)*largeur] > 0) return true;
	
	return false;
}




/* Les fontions ci-dessous servent à détecter les éventuelles lignes complétées par le joueur de façon à les supprimer et à faire évoluer le remplissage de la grille en conséquence */

bool ligne_complete(int* grille, int largeur, int hauteur, int ligne) 
// Pour une ligne donnée, cette fonction cherche si la ligne est complète. 
	{
		int j = ligne ;
		int complet = 0 ;

		for (int i=0; i<largeur; i++)
			{
				if(grille[i + j*largeur] != 0) complet+= 1 ;
			}
		if (complet == largeur) return(true) ;
		return(false);
	}

void verif_ligne(int* grille, int* score, int largeur, int hauteur) 
{

	*score = *score + SCORE_POSE;
	int  numero_ligne ; // numéro de la ligne complète la plus basse 
	int nb_ligne = 0 ; // nombre de lignes complètes

	int j = hauteur-1 ; 
	bool complet = false ;

	// Recherche de la ligne complète la plus basse
	while( (j>=3) && !(complet) ) 
		{
			complet = ligne_complete(grille, largeur, hauteur, j) ;
			if(complet) 
				{	numero_ligne = j ;
					nb_ligne = 1 ;
				}
			j-- ;
		}

	// Si on a trouvé une ligne complète, il faut vérifier si les 3 lignes au-dessus le sont 
	if(complet) 
		{
			j = numero_ligne-1 ;
			while( (j>=3) && (j>numero_ligne-4) && (complet) )  
			// On regarde les 3 lignes au-dessus de la ligne complète trouvée, en prenant garde à rester dans la grille. 
			// Si une ligne n'est pas complète, il n'y a pas d'intérêt à regarder celle située encore au-dessus. 
				{
					complet = ligne_complete(grille, largeur, hauteur, j) ;
					if(complet) nb_ligne+=1 ;
					j-- ;
				}
		}



	// Mise à jour de la grille 

	// Suppression des lignes complètes
	for(j = numero_ligne; j>numero_ligne-nb_ligne ; j-- )
		{
			for(int i = 0 ; i < largeur; i++) grille[i+j*largeur]= 0 ;
		}

	// Descente des cases dans la grille 
	
	int couleur;
	for(j = numero_ligne-nb_ligne ; j >= 0 ; j--)
	// La descente a lieu pour toutes les cases situées au-dessus du bloc de lignes complètes
		{
			for( int i = 0 ; i < largeur ; i++ ) 
				{ 
					couleur = grille[i + j*largeur] ;
					if ( couleur != grille[ i + (j+nb_ligne)*largeur ] ) 
						{
							grille[ i + (j+nb_ligne)*largeur ] = couleur ;
						}		
				}
		}

	// Mise à jour du score, en fonction du nombre de lignes supprimées

	switch (nb_ligne) {
		case 1: *score = *score + SCORE_1LIGNE; break;
		case 2: *score = *score + SCORE_2LIGNE; break;
		case 3: *score = *score + SCORE_3LIGNE; break;
		case 4: *score = *score + SCORE_4LIGNE; break;
		default: break;
	}
} 

