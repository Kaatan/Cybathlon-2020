/*Auteurs : Drouin ; Nicolini ; Richomme */

#ifndef __FUNCTION_H__
#define __FUNCTION_H__

struct piece {
	int couleur;
	int abs_centre;
	int ord_centre;
	int abs_1;
	int ord_1;
	int abs_2;
	int ord_2;
	int abs_3;
	int ord_3;
};

extern void delay(int temps);

#endif
