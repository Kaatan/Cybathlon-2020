/*Authors : Drouin ; Nicolini ; Richomme */

#include <stdlib.h>
#include <stdio.h>
#include <time.h>

#include "function.h"


void delay (int temps) {
	int t1 = clock();
	int t2 = clock();
	int delta = t2 - t1;

	while (delta < temps) {
		t2 = clock();
		delta = t2 - t1;
	}
}
