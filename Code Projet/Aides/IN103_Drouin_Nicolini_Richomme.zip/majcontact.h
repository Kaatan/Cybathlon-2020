/*Auteurs : Drouin ; Nicolini ; Richomme */

#ifndef __MAJCONTACT_H__
#define __MAJCONTACT_H__


extern bool perdu(int* grille, int largeur) ;

extern bool contact (int* grille, struct piece* piece, int largeur, int hauteur) ;

extern bool ligne_complete(int* grille, int largeur, int hauteur, int ligne) ;

extern void verif_ligne(int* grille, int* score, int largeur, int hauteur) ;


#endif 
