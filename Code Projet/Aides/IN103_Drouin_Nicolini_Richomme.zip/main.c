/*Auteurs : Drouin ; Nicolini ; Richomme */

//gcc main.c function.c majutilisateur.c majcontact.c affichage.c $(sdl-config --cflags --libs)

#include <stdlib.h>
#include <stdio.h>
#include <SDL.h>
#include <time.h>
#include <stdbool.h>

#include "function.h"
#include "majutilisateur.h"
#include "majcontact.h"
#include "affichage.h"


// Ensemble des paramètres

	//Dimensions de la grille
#define LARGEUR 12
#define HAUTEUR 23

	//Position dans la grille de la piece contrôlée à l'instant de son apparition
#define ABS_INIT 6
#define ORD_INIT 2

	//Nombre de frames par seconde
#define FPS 60

	//Définition des paramètres du gameplay
#define VITESSE_CHUTE_INIT 60. //temps (en frame) entre deux chutes obligatoires de la pièce au début de la partie
#define VITESSE_CHUTE_FINALE 10. //temps (en frame) entre deux chutes obligatoires de la pièce en fin de partie
#define DELAI_TEMPS_CHUTE 120. //le temps (en s) pour atteindre la vitesse de chute finale

	//Dimensions de l'affichage (unité : pixel)
#define LARGEUR_F ((int) 25*BLOCK_SIZE)
#define HAUTEUR_F ((int) 26*BLOCK_SIZE)

	//Abscisse et ordonnée de l'affichage du score en cours de partie
#define X_SCORE ((int) 15*BLOCK_SIZE + BLOCK_SIZE / 4 + NUMBER_BLOCK_SIZE)
#define Y_SCORE ((int) 8*BLOCK_SIZE - 6 * NUMBER_BLOCK_SIZE + NUMBER_BLOCK_SIZE / 2 +1)

SDL_Surface *g_screenSurface;

int main () {

	// Création des constantes calculées à partir des paramètres
		// Définition du temps minimal de frame (unité : clock)
	int TEMPS_FRAME_MIN = CLOCKS_PER_SEC / FPS;
		// Définition des constantes pour définir la vitesse de chute en fonction du temps de jeu
	int LIMITE_NB_TOUR = (DELAI_TEMPS_CHUTE * FPS);
	int LIMITE_DESCENTE_INIT = VITESSE_CHUTE_INIT;
	float DESCENTE_TOUR = (VITESSE_CHUTE_INIT - VITESSE_CHUTE_FINALE) / (DELAI_TEMPS_CHUTE * FPS);

	// Création de la fenêtre
	g_screenSurface = SDL_SetVideoMode (LARGEUR_F, HAUTEUR_F, 16, SDL_HWSURFACE | SDL_DOUBLEBUF);
	if (g_screenSurface == NULL) {
		printf("Impossible de créer l'affichage de dimensions %dx%d : %s\n", LARGEUR_F, HAUTEUR_F, SDL_GetError());
		SDL_Quit();
		return -1;
	}
	renderWalls();

	// Initialisation du hasard
	srand (time(0));


	// Création de la grille
	int* grille = malloc ((LARGEUR*HAUTEUR)*sizeof(int));
	if (grille == NULL) {
		printf ("Impossible d'allouer l'espace nécessaire à la grille\n");
		SDL_FreeSurface (g_screenSurface) ;
		SDL_Quit () ;
		return -1;
	}
		// Mise à zéro de la grille
	for (int i=0; i<LARGEUR; i++) {
		for (int j=0; j<HAUTEUR; j++) {
			grille[i + j * LARGEUR] = 0;
		}
	}


	// Création des pièces et de la liste des pièces
	struct piece Bloc = {1,ABS_INIT,ORD_INIT,1,0,0,1,1,1};
	struct piece S = {2,ABS_INIT,ORD_INIT,1,-1,1,0,0,1};
	struct piece S_inv = {3,ABS_INIT,ORD_INIT,0,-1,1,0,1,1};
	struct piece L = {4,ABS_INIT,ORD_INIT,0,-2,0,-1,1,0};
	struct piece L_inv = {5,ABS_INIT,ORD_INIT,0,-2,0,-1,-1,0};
	struct piece T = {6,ABS_INIT,ORD_INIT,-1,0,0,-1,1,0};
	struct piece Barre = {7,ABS_INIT,ORD_INIT,-1,0,1,0,2,0};
		// Liste des pièces
	struct piece liste_piece[7] = {Bloc,S,S_inv,L,L_inv,T,Barre};


	// Création du score
	static int score=0;


	// Initialisation de la pièce contrôlée par le joueur et de la pièce future
	struct piece piece_controle = liste_piece[rand()%7];
	struct piece piece_future = liste_piece[rand()%7];


	// Initialisation de l'affichage
	renderNextSpace();
	renderNext (piece_future.couleur);
	renderScore (score,X_SCORE,Y_SCORE);


	// Initialisation des valeurs propres à la boucle
	bool fin = false; //fin = true lorsque la partie se termine
	SDL_Event event;

	int t1;
	int t2;
	int delta;

	int compteur_descente = 0;
	int nb_tour_descente = 0;
	int rotation = 0;
	int decalage = 0;

	int limite_descente = LIMITE_DESCENTE_INIT;
	

	while (fin != true) {

		// Lancement du chronomètre
		t1 = clock();

		effacer (grille, piece_controle,LARGEUR);

		// Premier cas : si la pièce se pose
		if ((compteur_descente >= limite_descente) && (contact (grille, &piece_controle, LARGEUR, HAUTEUR) == 1)) {
			placer (grille, piece_controle,LARGEUR);
			// Mise à jour de la grille et du score : vérification des lignes complétées
			verif_ligne(grille, &score, LARGEUR, HAUTEUR);
			// Vérifier si on a perdu
			fin = perdu (grille,LARGEUR);
			// Si on n'a pas perdu
			if (fin != true) {
				// Création d'une nouvelle pièce contrôlée et de la pièce ultérieure
				piece_controle = piece_future;
				piece_future = liste_piece[rand()%7];
				compteur_descente = 0;
				// Mise à jour de l'affichage
				renderNextSpace();
				renderNext (piece_future.couleur);
				renderScore (score, X_SCORE, Y_SCORE);
			}
		}

		// Deuxième cas : la pièce ne se pose pas
		else {
			// Vérifier si la pièce doit descendre
			if (compteur_descente >= limite_descente) {
				// La pièce descend
				piece_controle.ord_centre += 1;
				// Remise à zéro du compteur de descente
				compteur_descente = 0;
			}
			// Vérification et application des commandes du joueur
			while (SDL_PollEvent (&event)) {
				if (event.type == SDL_QUIT) fin = true ;
				if (event.type == SDL_KEYDOWN) {
					switch (event.key.keysym.sym) {
						case SDLK_LEFT: decalage = -1 ; break ; //touche flèche gauche = déplacement à gauche
						case SDLK_RIGHT: decalage = 1 ; break ; //touche flèche droite = déplacement à droite
						case SDLK_DOWN: compteur_descente = limite_descente ; break ; //touche flèche bas = descente
						case SDLK_q: compteur_descente = 0; rotation = 1 ; break ; //touche q = rotation à gauche
						case SDLK_d: compteur_descente = 0;rotation = -1 ; break ; //touche d = rotation à droite
						case SDLK_ESCAPE: fin = true ; break ; //touche ESC = fin de la partie
						default: break ;
					}
					traitement_utilisateur (grille, &piece_controle, LARGEUR, HAUTEUR, rotation, decalage);
					rotation = 0;
					decalage = 0;
				}
			}
		}


		placer (grille, piece_controle, LARGEUR);

		// Mise à jour de l'affichage
		renderTableau (grille, LARGEUR, HAUTEUR);
		SDL_Flip (g_screenSurface);

		// Mise à jour des variables
		compteur_descente++;
		if (nb_tour_descente < LIMITE_NB_TOUR) nb_tour_descente ++;
		limite_descente = LIMITE_DESCENTE_INIT - (DESCENTE_TOUR * nb_tour_descente);
		//printf("nb tours = %d et limite = %d\n", nb_tour_descente, limite_descente);

		// Arrêt du chronomètre
		t2 = clock();

		// Attente de la prochaine boucle s'il reste encore du temps
		delta = t2-t1;
		if (delta < TEMPS_FRAME_MIN) {
			delay (TEMPS_FRAME_MIN - delta);
		}

	}

	// Affichage du "game over" et du score
	game_over(score);
	SDL_Flip (g_screenSurface);
	fin = false;
	while (fin != true) {
		while (SDL_PollEvent (&event)) {
			if (event.type == SDL_QUIT) fin = true ;
			if (event.type == SDL_KEYDOWN) {
				switch (event.key.keysym.sym) {
					case SDLK_ESCAPE: fin = true ; break ; //touche ESC = fini la partie
					default: break ;
				}
			}
		}
	}

	SDL_FreeSurface (g_screenSurface) ;
	SDL_Quit () ;

	printf ("Votre score est : %d\n", score);
	free (grille);

	return 0;
}
