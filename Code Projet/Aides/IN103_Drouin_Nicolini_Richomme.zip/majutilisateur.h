/*Auteurs : Drouin ; Nicolini ; Richomme */

#ifndef __MAJUTILISATEUR_H__
#define __MAJUTILISATEUR_H__

extern void effacer(int* grille, struct piece une_piece , int largeur) ;
extern void placer(int* grille, struct piece une_piece , int largeur) ;

extern int verif_decalage(int* grille, struct piece* une_piece, int largeur, int decalage)  ;

extern int* calcul_rotation(int abscisse, int ordonnee, int rotation) ;
extern int* coord_rotation(int* grille, struct piece* une_piece, int largeur, int hauteur, int rotation) ;

extern void traitement_utilisateur(int* grille, struct piece* une_piece, int largeur, int hauteur, int rotation, int decalage) ;
	
#endif







