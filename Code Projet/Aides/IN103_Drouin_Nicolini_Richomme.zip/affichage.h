/*Auteurs : Drouin ; Nicolini ; Richomme */

#ifndef __AFFICHAGE_H__
#define __AFFICHAGE_H__

extern SDL_Surface *g_screenSurface;

#define BLOCK_SIZE ((int) 20) // De même, pour les blocs d'affichage valeur parmi 40, 30, 20, 10
#define NUMBER_BLOCK_SIZE ((int) (BLOCK_SIZE*3)/10) //Valeurs possibles pour la taille du bloc (pour les nombres en pixels) : de 12, 8, 6, 3


Uint32 getPixel (SDL_Surface *surface, int x, int y);

void CaseConversion (int c,int rgb[3]); //Permet d'obenir les couleurs RGB d'une case en fonction de son numéro n et de les stocker dans la variable rgb[]

void renderPixel (int x, int y, Uint8 R, Uint8 G, Uint8 B); //affiche un pixel

void renderSquare(int x, int y, Uint8 r, Uint8 g, Uint8 b, int size); //affiche un carré de largeur size en x,y de couleurs r,g,b

void renderShade(int x, int y, Uint8 r, Uint8 g, Uint8 b, int size); //affiche les ombres d'un carré de largeur size en x,y de couleurs r,g,b

void renderBlock(int x, int y, Uint8 r, Uint8 g, Uint8 b, int size); //affiche un carré avec ses ombres

void renderNumber(int x, int y, int n); //affiche l'entier n à l'emplacement (x,y)


extern void game_over(int score); //affiche un écran noir sur lequel sont écrit "GAME OVER" ainsi que le score du joueur

extern void renderTableau(int* tableau, int largeur, int hauteur); //affiche le tableau des pièces posées et en train de tomber. Prend en argument le tableau ainsi que ses dimensions d'affichage.

extern void renderNextSpace(); //affiche le fond noir pour la pièce suivante et le score

extern void renderNext(int n); //affiche la pièce suivante dans l'espace créé par renderNextSpace. n correspond au code numérique de la pièce (allant de 1 à 7)

extern void renderScore(int score, int x, int y); //affiche le score en (x,y)

extern void renderWalls(); //affiche les murs du décor. La fonction affiche tous les blocs qui seront ensuite recouverts avec les autres blocs du décor

extern SDL_Surface *g_screenSurface ;

#endif
