/*Auteurs : Drouin ; Nicolini ; Richomme */

#include <stdio.h>
#include <stdlib.h>
#include <SDL.h>
#include "affichage.h"
#include "function.h"



// Variables locales


#define SHADE ((int) 30) //Variable qui détermine le degré d'ombrage des pixels
#define LIGHT ((int) 20) //Variable qui détermine le degré de luminosité des pixels


  //Taille de l'écran en blocs d'affichage :
#define SCREEN_BLOCK_HEIGHT ((int) 25)
#define SCREEN_BLOCK_WIDTH ((int) 26)


//Prend en argument un numéro c associé à une pièce donc à une couleur et modifie le tableau rgb pour associer à chaque place du tableau la couleur r, g, b correspondante
void CaseConversion (int c, int rgb[3]){

  switch (c){
    case 0 : //Noir
      rgb[0] = 0;
      rgb[1] = 0;
      rgb[2] = 0;
      break;
    case 1 : //Pièce Carrée
      rgb[0] = 200;
      rgb[1] = 200;
      rgb[2] = 200;
      break;
    case 2 : //Pièce S
      rgb[0] = 255;
      rgb[1] = 20;
      rgb[2] = 20;
      break;
    case 3 : //Pièce S inversé
      rgb[0] = 255;
      rgb[1] = 135;
      rgb[2] = 26;
      break;
    case 4 : //Pièce L
      rgb[0] = 163;
      rgb[1] = 57;
      rgb[2] = 186;
      break;
    case 5 : //Pièce L Inversé
      rgb[0] = 230;
      rgb[1] = 223;
      rgb[2] = 76;
      break;
    case 6 : //Pièce T
      rgb[0] = 100;
      rgb[1] = 230;
      rgb[2] = 76;
      break;
    case 7 : //Pièce Barre
      rgb[0] = 76;
      rgb[1] = 158;
      rgb[2] = 230;
      break;
    default : break;
  }

}


//Affiche un pixel de couleurs R, G, B à l'emplacement x, y de l'écran
void renderPixel (int x, int y, Uint8 R, Uint8 G, Uint8 B)
// Fonction disponible dans l'un des TD 
{
  Uint32 color = SDL_MapRGB (g_screenSurface->format, R, G, B) ;

  switch (g_screenSurface->format->BytesPerPixel) {
  case 1: { // Assuming 8-bpp
    Uint8 *bufp;
    bufp = (Uint8*) g_screenSurface->pixels + y*g_screenSurface->pitch + x ;
    *bufp = color;
    }
    break ;

  case 2: { // Probably 15-bpp or 16-bpp
    Uint16 *bufp;
    bufp = (Uint16*) g_screenSurface->pixels + y*g_screenSurface->pitch/2 + x ;
    *bufp = color;
    }
    break ;

  case 3: { // Slow 24-bpp mode, usually not used
    Uint8 *bufp;
    bufp = (Uint8*) g_screenSurface->pixels + y*g_screenSurface->pitch + x * 3;
    if (SDL_BYTEORDER == SDL_LIL_ENDIAN) {
      bufp[0] = color;
      bufp[1] = color >> 8;
      bufp[2] = color >> 16;
    }
    else {
      bufp[2] = color;
      bufp[1] = color >> 8;
      bufp[0] = color >> 16;
    }
    }
    break ;

  case 4: { // Probably 32-bpp
    Uint32 *bufp;
    bufp = (Uint32*) g_screenSurface->pixels + y*g_screenSurface->pitch/4 + x;
    *bufp = color;
    }
    break ;
  }
}


//Affiche un carré de largeur size de couleur r, g, b en (x,y)
void renderSquare(int x, int y, Uint8 r, Uint8 g, Uint8 b, int size){
  for (int i=0; i<size; i++){
    for (int j=0; j<size; j++){
      renderPixel(x+i, y+j, r, g, b);
    }
  }
}


//Affiche les ombres d'un carré de largeur size de couleur r, g, b en (x,y)
void renderShade(int x, int y, Uint8 r, Uint8 g, Uint8 b, int size){
  //Définition de la largeur de la bande d'ombre ou de lumière
  int edge=size/5;

  Uint8 rshade, bshade, gshade; //Variable pour stocker les couleurs altérées

  if (r>=SHADE){
    rshade=r-SHADE;
  }
  else{
    rshade=0;
  }
  if (g>=SHADE){
    gshade=g-SHADE;
  }
  else{
    gshade=0;
  }
  if (b>=SHADE){
    bshade=b-SHADE;
  }
  else{
    bshade=0;
  }

  if (r<=(255-LIGHT)){
    r+=LIGHT;
  }
  else{
    r=255;
  }
  if (g<=(255-LIGHT)){
    g+=LIGHT;
  }
  else{
    g=255;
  }
  if (b<=(255-LIGHT)){
    b+=LIGHT;
  }
  else{
    b=255;
  }


  //Affichage des couleurs altérées sur un trapèze sur les bords du bloc
  for (int i=0; i<size; i++){
    for (int j=0; j<edge && j<=i && j<=(size-i); j++){
        renderPixel(x+i, y+j, r, g, b);
        renderPixel(x+i, y+size-j, rshade, gshade, bshade);
        renderPixel(x+j, y+i, r, g, b);
        renderPixel(x+size-j, y+i, rshade, gshade, bshade);
    }
  }
}

//Permet d'afficher un bloc avec des ombres et des lumières de couleur r, g, b en (x,y)
void renderBlock(int x, int y, Uint8 r, Uint8 g, Uint8 b, int size){
  renderSquare(x,y,r,g,b,size);
  renderShade(x,y,r,g,b,size);
}


//Prend en argument le tableau de largeur et de hauteur connues des pièces actuelles (posées et en train de tomber) et l'affiche
void renderTableau(int tableau[], int largeur, int hauteur){
  int l=largeur;
  int h=hauteur;
  int rgb[3];

  //Abscisse et ordonnée des blocs que l'on va afficher
  int x,y;
  for (int i=0; i<l; i++){
    for (int j=3; j<h; j++){ //j part de 3 car les trois premières lignes du tableau ne doivent pas être affichées
      int color = tableau[i+j*l];
      CaseConversion(color,rgb);
      int r=rgb[0];
      int g=rgb[1];
      int b=rgb[2];

      x=i*BLOCK_SIZE+2*BLOCK_SIZE;
      y=j*BLOCK_SIZE;
      // l'ajout de 3*BLOCK_SIZE correspond aux bords de l'écran que l'on veut préserver
      renderBlock(x,y,r,g,b,BLOCK_SIZE);
    }
  }
}


//Permet d'afficher le rectangle noir pour la pièce suivante et le score
void renderNextSpace(){
  //Abscisse et ordonnée du premier bloc noir ainsi que sa hauteur, réservé à la pièce suivante
  int nextx=BLOCK_SIZE * 15;
  int nexty=BLOCK_SIZE * 15 +1;
  int spacewidth= 8 * BLOCK_SIZE;
  int spaceheight= 5 * BLOCK_SIZE -1 ;

  //Hauteur et ordonnée du second espace, réservé au score
  int nspaceheight = 7*NUMBER_BLOCK_SIZE;
  int numby = 7* BLOCK_SIZE -  nspaceheight;

  for (int i=0; i<spacewidth; i++){
    for (int j=0; j<spaceheight; j++){
      renderPixel(nextx+i, nexty+j, 0, 0, 0);
    }
    for (int k=0; k<nspaceheight; k++){
      renderPixel(nextx+i, numby+k, 0 ,0 ,0);
    }
  }
}


//Affiche la pièce suivante dans le cadre prévu par la fonction renderNextSpace. Prend en agument un nombre entier n qui correspond au numéro associé à une case du tableau, à partir duquel on peut extraire la couleur grâce à CaseConversion. Ce nombre caractérise aussi la forme de la pièce.
void renderNext(int n){

  //Abscisse et ordonnée du début de l'affichage
  int x=BLOCK_SIZE * 18;
  int y=BLOCK_SIZE * 17;

  //Récupération des couleurs du bloc.
  int rgb[3];
  CaseConversion(n, rgb);
  int r=rgb[0];
  int g=rgb[1];
  int b=rgb[2];

  switch (n) {
    case 1 : //Pièce Carré
    renderBlock(x,y,r,g,b,BLOCK_SIZE);
    renderBlock(x+BLOCK_SIZE,y,r,g,b,BLOCK_SIZE);
    renderBlock(x+BLOCK_SIZE,y+BLOCK_SIZE,r,g,b,BLOCK_SIZE);
    renderBlock(x,y+BLOCK_SIZE,r,g,b,BLOCK_SIZE);
    break;
    case 2 : //Pièce S
    renderBlock(x,y,r,g,b,BLOCK_SIZE);
    renderBlock(x+BLOCK_SIZE,y,r,g,b,BLOCK_SIZE);
    renderBlock(x+BLOCK_SIZE,y-BLOCK_SIZE,r,g,b,BLOCK_SIZE);
    renderBlock(x,y+BLOCK_SIZE,r,g,b,BLOCK_SIZE);
    break;
    case 3 : //Pièce S inversé
    renderBlock(x,y,r,g,b,BLOCK_SIZE);
    renderBlock(x,y-BLOCK_SIZE,r,g,b,BLOCK_SIZE);
    renderBlock(x+BLOCK_SIZE,y,r,g,b,BLOCK_SIZE);
    renderBlock(x+BLOCK_SIZE,y+BLOCK_SIZE,r,g,b,BLOCK_SIZE);
    break;
    case 4 : //Pièce L
    renderBlock(x,y,r,g,b,BLOCK_SIZE);
    renderBlock(x,y-BLOCK_SIZE,r,g,b,BLOCK_SIZE);
    renderBlock(x,y+BLOCK_SIZE,r,g,b,BLOCK_SIZE);
    renderBlock(x+BLOCK_SIZE,y+BLOCK_SIZE,r,g,b,BLOCK_SIZE);
    break;
    case 5 : //Pièce L inversé
    renderBlock(x+BLOCK_SIZE,y,r,g,b,BLOCK_SIZE);
    renderBlock(x+BLOCK_SIZE,y-BLOCK_SIZE,r,g,b,BLOCK_SIZE);
    renderBlock(x+BLOCK_SIZE,y+BLOCK_SIZE,r,g,b,BLOCK_SIZE);
    renderBlock(x,y+BLOCK_SIZE,r,g,b,BLOCK_SIZE);
    break;
    case 6 : //Pièce T
    renderBlock(x,y,r,g,b,BLOCK_SIZE);
    renderBlock(x,y-BLOCK_SIZE,r,g,b,BLOCK_SIZE);
    renderBlock(x+BLOCK_SIZE,y,r,g,b,BLOCK_SIZE);
    renderBlock(x-BLOCK_SIZE,y,r,g,b,BLOCK_SIZE);
    break;
    case 7 : //Pièce barre
    renderBlock(x,y,r,g,b,BLOCK_SIZE);
    renderBlock(x-BLOCK_SIZE,y,r,g,b,BLOCK_SIZE);
    renderBlock(x+BLOCK_SIZE,y,r,g,b,BLOCK_SIZE);
    renderBlock(x+2*BLOCK_SIZE,y,r,g,b,BLOCK_SIZE);
    break;
  }
}

//Affiche le nombre n en (x,y)
void renderNumber(int x, int y, int n){
  int a = NUMBER_BLOCK_SIZE; //alléger le code

  //Définition d'une couleur jaune pour les nombres
  int r=247;
  int g=255;
  int b=60;

  switch (n) {
    case 0 :
    renderSquare(x,y,r,g,b,a);
    renderSquare(x,y-a,r,g,b,a);
    renderSquare(x,y-2*a,r,g,b,a);
    renderSquare(x,y-3*a,r,g,b,a);
    renderSquare(x,y-4*a,r,g,b,a);
    renderSquare(x+a,y,r,g,b,a);
    renderSquare(x+a,y-4*a,r,g,b,a);
    renderSquare(x+2*a,y,r,g,b,a);
    renderSquare(x+2*a,y-a,r,g,b,a);
    renderSquare(x+2*a,y-2*a,r,g,b,a);
    renderSquare(x+2*a,y-3*a,r,g,b,a);
    renderSquare(x+2*a,y-4*a,r,g,b,a);
    break;

    case 1 :
    renderSquare(x+2*a,y,r,g,b,a);
    renderSquare(x+2*a,y-a,r,g,b,a);
    renderSquare(x+2*a,y-2*a,r,g,b,a);
    renderSquare(x+2*a,y-3*a,r,g,b,a);
    renderSquare(x+2*a,y-4*a,r,g,b,a);
    break;

    case 2 :
    renderSquare(x,y,r,g,b,a);
    renderSquare(x,y-a,r,g,b,a);
    renderSquare(x,y-2*a,r,g,b,a);

    renderSquare(x,y-4*a,r,g,b,a);
    renderSquare(x+a,y,r,g,b,a);

    renderSquare(x+a,y-2*a,r,g,b,a);

    renderSquare(x+a,y-4*a,r,g,b,a);
    renderSquare(x+2*a,y,r,g,b,a);

    renderSquare(x+2*a,y-2*a,r,g,b,a);
    renderSquare(x+2*a,y-3*a,r,g,b,a);
    renderSquare(x+2*a,y-4*a,r,g,b,a);
    break;

    case 3 :
    renderSquare(x,y,r,g,b,a);

    renderSquare(x,y-2*a,r,g,b,a);

    renderSquare(x,y-4*a,r,g,b,a);
    renderSquare(x+a,y,r,g,b,a);

    renderSquare(x+a,y-2*a,r,g,b,a);

    renderSquare(x+a,y-4*a,r,g,b,a);
    renderSquare(x+2*a,y,r,g,b,a);
    renderSquare(x+2*a,y-a,r,g,b,a);
    renderSquare(x+2*a,y-2*a,r,g,b,a);
    renderSquare(x+2*a,y-3*a,r,g,b,a);
    renderSquare(x+2*a,y-4*a,r,g,b,a);
    break;

    case 4 :

    renderSquare(x,y-2*a,r,g,b,a);
    renderSquare(x,y-3*a,r,g,b,a);
    renderSquare(x,y-4*a,r,g,b,a);

    renderSquare(x+a,y-2*a,r,g,b,a);

    renderSquare(x+2*a,y,r,g,b,a);
    renderSquare(x+2*a,y-a,r,g,b,a);
    renderSquare(x+2*a,y-2*a,r,g,b,a);
    renderSquare(x+2*a,y-3*a,r,g,b,a);
    renderSquare(x+2*a,y-4*a,r,g,b,a);
    break;

    case 5 :
    renderSquare(x,y,r,g,b,a);

    renderSquare(x,y-2*a,r,g,b,a);
    renderSquare(x,y-3*a,r,g,b,a);
    renderSquare(x,y-4*a,r,g,b,a);
    renderSquare(x+a,y,r,g,b,a);

    renderSquare(x+a,y-2*a,r,g,b,a);

    renderSquare(x+a,y-4*a,r,g,b,a);
    renderSquare(x+2*a,y,r,g,b,a);
    renderSquare(x+2*a,y-a,r,g,b,a);
    renderSquare(x+2*a,y-2*a,r,g,b,a);

    renderSquare(x+2*a,y-4*a,r,g,b,a);
    break;

    case 6 :
    renderSquare(x,y-a,r,g,b,a);
    renderSquare(x,y,r,g,b,a);

    renderSquare(x,y-2*a,r,g,b,a);
    renderSquare(x,y-3*a,r,g,b,a);
    renderSquare(x,y-4*a,r,g,b,a);
    renderSquare(x+a,y,r,g,b,a);

    renderSquare(x+a,y-2*a,r,g,b,a);

    renderSquare(x+a,y-4*a,r,g,b,a);
    renderSquare(x+2*a,y,r,g,b,a);
    renderSquare(x+2*a,y-a,r,g,b,a);
    renderSquare(x+2*a,y-2*a,r,g,b,a);

    renderSquare(x+2*a,y-4*a,r,g,b,a);
    break;

    case 7 :

    renderSquare(x,y-4*a,r,g,b,a);

    renderSquare(x+a,y-4*a,r,g,b,a);

    renderSquare(x+2*a,y,r,g,b,a);
    renderSquare(x+2*a,y-a,r,g,b,a);
    renderSquare(x+2*a,y-2*a,r,g,b,a);
    renderSquare(x+2*a,y-3*a,r,g,b,a);
    renderSquare(x+2*a,y-4*a,r,g,b,a);
    break;

    case 8 :
    renderSquare(x,y,r,g,b,a);
    renderSquare(x,y-a,r,g,b,a);
    renderSquare(x,y-2*a,r,g,b,a);
    renderSquare(x,y-3*a,r,g,b,a);
    renderSquare(x,y-4*a,r,g,b,a);
    renderSquare(x+a,y,r,g,b,a);

    renderSquare(x+a,y-2*a,r,g,b,a);

    renderSquare(x+a,y-4*a,r,g,b,a);
    renderSquare(x+2*a,y,r,g,b,a);
    renderSquare(x+2*a,y-a,r,g,b,a);
    renderSquare(x+2*a,y-2*a,r,g,b,a);
    renderSquare(x+2*a,y-3*a,r,g,b,a);
    renderSquare(x+2*a,y-4*a,r,g,b,a);
    break;

    case 9 :
    renderSquare(x,y,r,g,b,a);

    renderSquare(x,y-2*a,r,g,b,a);
    renderSquare(x,y-3*a,r,g,b,a);
    renderSquare(x,y-4*a,r,g,b,a);
    renderSquare(x+a,y,r,g,b,a);

    renderSquare(x+a,y-2*a,r,g,b,a);

    renderSquare(x+a,y-4*a,r,g,b,a);
    renderSquare(x+2*a,y,r,g,b,a);
    renderSquare(x+2*a,y-a,r,g,b,a);
    renderSquare(x+2*a,y-2*a,r,g,b,a);
    renderSquare(x+2*a,y-3*a,r,g,b,a);
    renderSquare(x+2*a,y-4*a,r,g,b,a);
    break;
  }
}

  //Affiche le score à l'emplacement (x,y)
void renderScore(int score,int x,int y){

    //Obtention des différents chiffres du score
  int n0 = score/100000;
  int n1 = (score-n0*100000)/10000;
  int n2 = (score-n0*100000-n1*10000)/1000;
  int n3 = (score-n0*100000-n1*10000-n2*1000)/100;
  int n4 = (score-n0*100000-n1*10000-n2*1000-n3*100)/10;
  int n5 = (score-n0*100000-n1*10000-n2*1000-n3*100-n4*10)/1;


  int a = NUMBER_BLOCK_SIZE; //alléger les notations
  renderNumber(x,y,n0);
  renderNumber(x+4*a, y, n1);
  renderNumber(x+8*a, y, n2);
  renderNumber(x+12*a, y, n3);
  renderNumber(x+16*a, y, n4);
  renderNumber(x+20*a, y, n5);

}


  //Affiche les murs, à savoir les blocs gris qui encadrent l'écran de jeu, le score et la pièce suivante.
void renderWalls(){
  for (int i=0; i<SCREEN_BLOCK_HEIGHT; i++){
    for (int j=0; j<SCREEN_BLOCK_WIDTH; j++){
      renderBlock(i*BLOCK_SIZE, j*BLOCK_SIZE, 150, 150, 150, BLOCK_SIZE);
    }
  }
}



  //Affiche GAME OVER et le score sur un écran noir
void game_over(int score){

    //Abscisse et ordonnée du GAME OVER
  int x0=5 * BLOCK_SIZE;
  int y0=5 * BLOCK_SIZE;

  int a=BLOCK_SIZE;

    //Affiche l'écran noir
  for (int i=0; i<BLOCK_SIZE*SCREEN_BLOCK_HEIGHT; i++){
    for (int j=0; j<BLOCK_SIZE*SCREEN_BLOCK_WIDTH; j++){
      renderPixel(i,j,0,0,0);
    }
  }



    //Couleurs de l'affichage du GAME OVER
  Uint8 r=247;
  Uint8 g=255;
  Uint8 b=60;

    //Pour G
  renderSquare(x0,y0,r,g,b,a);
  renderSquare(x0+a,y0,r,g,b,a);
  renderSquare(x0+2*a,y0,r,g,b,a);
  renderSquare(x0,y0+a,r,g,b,a);
  renderSquare(x0,y0+2*a,r,g,b,a);
  renderSquare(x0+2*a,y0+2*a,r,g,b,a);
  renderSquare(x0,y0+3*a,r,g,b,a);
  renderSquare(x0+2*a,y0+3*a,r,g,b,a);
  renderSquare(x0,y0+4*a,r,g,b,a);
  renderSquare(x0+a,y0+4*a,r,g,b,a);
  renderSquare(x0+2*a,y0+4*a,r,g,b,a);

    //Pour A
  x0+=4*a;
  renderSquare(x0,y0,r,g,b,a);
  renderSquare(x0+a,y0,r,g,b,a);
  renderSquare(x0+2*a,y0,r,g,b,a);
  renderSquare(x0,y0+a,r,g,b,a);
  renderSquare(x0+2*a,y0+a,r,g,b,a);
  renderSquare(x0,y0+2*a,r,g,b,a);
  renderSquare(x0+a,y0+2*a,r,g,b,a);
  renderSquare(x0+2*a,y0+2*a,r,g,b,a);
  renderSquare(x0,y0+3*a,r,g,b,a);
  renderSquare(x0+2*a,y0+3*a,r,g,b,a);
  renderSquare(x0,y0+4*a,r,g,b,a);
  renderSquare(x0+2*a,y0+4*a,r,g,b,a);

    //Pour M
  x0+=4*a;
  renderSquare(x0,y0,r,g,b,a);
  renderSquare(x0+2*a,y0,r,g,b,a);
  renderSquare(x0,y0+a,r,g,b,a);
  renderSquare(x0+a,y0+a,r,g,b,a);
  renderSquare(x0+2*a,y0+a,r,g,b,a);
  renderSquare(x0,y0+2*a,r,g,b,a);
  renderSquare(x0+2*a,y0+2*a,r,g,b,a);
  renderSquare(x0,y0+3*a,r,g,b,a);
  renderSquare(x0+2*a,y0+3*a,r,g,b,a);
  renderSquare(x0,y0+4*a,r,g,b,a);
  renderSquare(x0+2*a,y0+4*a,r,g,b,a);

    //Pour E du haut
  x0+=4*a;
  renderSquare(x0,y0,r,g,b,a);
  renderSquare(x0+a,y0,r,g,b,a);
  renderSquare(x0+2*a,y0,r,g,b,a);
  renderSquare(x0,y0+a,r,g,b,a);
  renderSquare(x0,y0+2*a,r,g,b,a);
  renderSquare(x0+a,y0+2*a,r,g,b,a);
  renderSquare(x0,y0+3*a,r,g,b,a);
  renderSquare(x0,y0+4*a,r,g,b,a);
  renderSquare(x0+a,y0+4*a,r,g,b,a);
  renderSquare(x0+2*a,y0+4*a,r,g,b,a);

    //Pour O
  x0=x0-12*a;
  y0+=6*a;
  renderSquare(x0,y0,r,g,b,a);
  renderSquare(x0+a,y0,r,g,b,a);
  renderSquare(x0+2*a,y0,r,g,b,a);
  renderSquare(x0,y0+a,r,g,b,a);
  renderSquare(x0+2*a,y0+a,r,g,b,a);
  renderSquare(x0,y0+2*a,r,g,b,a);
  renderSquare(x0+2*a,y0+2*a,r,g,b,a);
  renderSquare(x0,y0+3*a,r,g,b,a);
  renderSquare(x0+2*a,y0+3*a,r,g,b,a);
  renderSquare(x0,y0+4*a,r,g,b,a);
  renderSquare(x0+a,y0+4*a,r,g,b,a);
  renderSquare(x0+2*a,y0+4*a,r,g,b,a);

    //Pour V
  x0+=4*a;
  renderSquare(x0,y0,r,g,b,a);
  renderSquare(x0+2*a,y0,r,g,b,a);
  renderSquare(x0,y0+a,r,g,b,a);
  renderSquare(x0+2*a,y0+a,r,g,b,a);
  renderSquare(x0,y0+2*a,r,g,b,a);
  renderSquare(x0+2*a,y0+2*a,r,g,b,a);
  renderSquare(x0,y0+3*a,r,g,b,a);
  renderSquare(x0+2*a,y0+3*a,r,g,b,a);
  renderSquare(x0+a,y0+4*a,r,g,b,a);

    //Pour E du bas
  x0+=4*a;
  renderSquare(x0,y0,r,g,b,a);
  renderSquare(x0+a,y0,r,g,b,a);
  renderSquare(x0+2*a,y0,r,g,b,a);
  renderSquare(x0,y0+a,r,g,b,a);
  renderSquare(x0,y0+2*a,r,g,b,a);
  renderSquare(x0+a,y0+2*a,r,g,b,a);
  renderSquare(x0,y0+3*a,r,g,b,a);
  renderSquare(x0,y0+4*a,r,g,b,a);
  renderSquare(x0+a,y0+4*a,r,g,b,a);
  renderSquare(x0+2*a,y0+4*a,r,g,b,a);

    //Pour R
  x0+=4*a;
  renderSquare(x0,y0,r,g,b,a);
  renderSquare(x0+a,y0,r,g,b,a);
  renderSquare(x0+2*a,y0,r,g,b,a);
  renderSquare(x0,y0+a,r,g,b,a);
  renderSquare(x0+2*a,y0+a,r,g,b,a);
  renderSquare(x0,y0+2*a,r,g,b,a);
  renderSquare(x0+a,y0+2*a,r,g,b,a);
  renderSquare(x0+2*a,y0+2*a,r,g,b,a);
  renderSquare(x0,y0+3*a,r,g,b,a);
  renderSquare(x0+a,y0+3*a,r,g,b,a);
  renderSquare(x0,y0+4*a,r,g,b,a);
  renderSquare(x0+2*a,y0+4*a,r,g,b,a);

    //Abscisse et ordonnée pour l'affichage du score
  int y=y0+8*a;
  int x=x0-8*a;

  renderScore(score, x, y);

}
